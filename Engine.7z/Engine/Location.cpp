#include "Location.h"

void Location::Add(const Location& val)
{
	x += val.x;
	y += val.y;
}
